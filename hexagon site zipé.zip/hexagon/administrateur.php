<style type="text/css">



</style>
<?php

include "verifadmin.php";
?>


<html>
<head>
  <link href="https://fonts.googleapis.com/css?family=Montserrat|Raleway" rel="stylesheet">
  <title>Admin</title>
  <meta charset="UTF-8">
  <link rel="stylesheet" type="text/css" href="administrateur.css" /> 
   
</head>
<body >
 <div class="snip1231">
 <a  class="current" href="deconnexion.php">Déconnexion</a>
    </div>


  <div id="contents">

  <a class="snip0072" href="administrateur_afficherclient.php">Afficher les clients </a>
 <a class="snip0072 blue"href="administrateur_nouscontacter.php"> Messages reçus</a>
 <a class="snip0072 red"href="administrateur_affichercatalogue.php"> Afficher le catalogue</a>
 <a class="snip0072 orange"href="administrateur_modifierapropos.php"> Modifier "à propos"</a>
  <a class="snip0072 yellow"href="administrateur_afficherconsignes.php"> Consignes globales</a>
  <a class="snip0072 green"href="administrateur_afficherFAQ.php"> Afficher la page "aide"</a>
</div>
</body>


