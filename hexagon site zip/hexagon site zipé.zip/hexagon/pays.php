
    <select name='pays' required>
          <option value="Albanie"<?php if($user['pays'] == 'Albanie') echo "selected"; ?>>Albanie </option>
          <option value="Algerie"<?php if($user['pays'] == 'Algerie') echo "selected"; ?>>Algerie </option>
          <option value="Allemagne"<?php if($user['pays'] == 'Allemagne') echo "selected"; ?>>Allemagne </option>
          <option value="Belgique"<?php if($user['pays'] == 'Belgique') echo "selected"; ?>>Belgique </option>
          <option value="Canada"<?php if($user['pays'] == 'Canada') echo "selected"; ?>>Canada </option>
          <option value="Croatie"<?php if($user['pays'] == 'Croatie') echo "selected"; ?>>Croatie </option>
          <option value="Espagne"<?php if($user['pays'] == 'Espagne') echo "selected"; ?>>Espagne </option>
          <option value="France"<?php if($user['pays'] == 'France') echo "selected"; ?>>France </option>
          <option value="Italie"<?php if($user['pays'] == 'Italie') echo "selected"; ?>>Italie </option>
          <option value="Luxembourg"<?php if($user['pays'] == 'Luxembourg') echo "selected"; ?>>Luxembourg </option>
          <option value="Royaume_Uni"<?php if($user['pays'] == 'Royaume_Uni') echo "selected"; ?>>Royaume Uni </option>
          <option value="Suisse"<?php if($user['pays'] == 'Suisse') echo "selected"; ?>>Suisse </option>
</select>
