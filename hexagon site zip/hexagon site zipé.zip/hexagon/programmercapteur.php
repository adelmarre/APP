<head>
	<title>Programmer le capteur choisi</title>
	  <meta charset="UTF-8">
  <link rel="stylesheet" type="text/css" href="sallestyle.css" /> 
</head>
<?php session_start(); include "menu.php";?>
<?php 


$idhab = $_GET['id_habitation'];
if (isset($_GET['q']))   {
$q = $_GET["q"];


}
$idtype = $_GET['type'];
$idcapt = $_GET['modif'];

$h = $idhab ;

 $luminosite = $bdd -> prepare('SELECT * FROM type_capteur JOIN capteurpiece ON type_capteur.id_type_capteur=capteurpiece.id_type WHERE id_type=? AND id_piece=?');
  $luminosite ->  execute(array(1,$q));
  $temperature = $bdd -> prepare('SELECT * FROM type_capteur JOIN capteurpiece ON type_capteur.id_type_capteur=capteurpiece.id_type WHERE id_type=? AND id_piece=?');
  $temperature ->  execute(array(2,$q));
  $mouvement = $bdd -> prepare('SELECT * FROM type_capteur JOIN capteurpiece ON type_capteur.id_type_capteur=capteurpiece.id_type WHERE id_type=? AND id_piece=?');
  $mouvement ->  execute(array(3,$q));
  $fumee = $bdd -> prepare('SELECT * FROM type_capteur JOIN capteurpiece ON type_capteur.id_type_capteur=capteurpiece.id_type WHERE id_type=? AND id_piece=?');
  $fumee ->  execute(array(4,$q));
  $volet = $bdd -> prepare('SELECT * FROM type_capteur JOIN capteurpiece ON type_capteur.id_type_capteur=capteurpiece.id_type WHERE id_type=? AND id_piece=?');
  $volet ->  execute(array(5,$q));
  $humidite = $bdd -> prepare('SELECT * FROM type_capteur JOIN capteurpiece ON type_capteur.id_type_capteur=capteurpiece.id_type WHERE id_type=? AND id_piece=?');
  $humidite ->  execute(array(6,$q));
if ($idtype==1) {
	include "affichagecaptl.php";
}
if ($idtype==2) {
	include "affichagecaptt.php";
}
if ($idtype==3) {
	include "affichagecaptm.php";
}
if ($idtype==4) {
	include "affichagecaptf.php";
}
if ($idtype==5) {
	include "affichagecaptv.php";
}
if ($idtype==6) {
	include "affichagecapth.php";
}
         		
if(isset($_POST['activer']))
        { 
        	
        	if( !empty($_POST['inserdate']) AND !empty($_POST['inserheure'])) 
    		{
    	
    			$date = date("Y-m-d");
        		$heure = date("H:i:s");
        		$inserdate = htmlspecialchars($_POST['inserdate']);
        		$inserheure = htmlspecialchars($_POST['inserheure']);
        		
					  if (!empty($_POST['mouvement'])) {
					     foreach ($_POST['mouvement'] as $select)
					      {
					        $o =explode(',',$select);  

					        $date = date("Y-m-d");
					        $heure = date("H:i:s");

					        $insertcapteur = $bdd->prepare("UPDATE capteurpiece SET valeur=? WHERE id_capteur_piece = ? ");
					        $insertcapteur-> execute(array($o[1],$o[0]));

					         $Recup = $bdd->prepare("SELECT valeur,capteurpiece.id_type,id_capteur_piece,reference,id_piece from capteurpiece JOIN catalogue ON capteurpiece.id_capteur_catalogue=catalogue.id_capteur WHERE id_capteur_piece= ? AND id_capteur_catalogue = ?");
					        $Recup-> execute(array($o[0],$o[2]));

					        $Rec=$Recup->fetch();
					                   

					        $inserthistorique = $bdd->prepare("INSERT INTO donnees(valeur, ladate, heure, id_piece, id_type,id_capteur_piece, numero) VALUES( ?, ?,?, ?, ?, ?,?)");
					        $inserthistorique-> execute(array($Rec['valeur'],$date ,$heure ,$Rec['id_piece'] ,$Rec['id_type'], $Rec['id_capteur_piece'], $Rec['reference'] ));
					  
					      }
					  }
					  if (!empty($_POST['fumee'])) {
					     foreach ($_POST['fumee'] as $select)
					      {
					        $o =explode(',',$select);  
					        
					        $insertcapteur = $bdd->prepare("UPDATE capteurpiece SET valeur=? WHERE id_capteur_piece = ? ");
					        $insertcapteur-> execute(array($o[1],$o[0]));

					        $date= date("Y-m-d");
					        $heure = date("H:i:s");

					       $Recup = $bdd->prepare("SELECT valeur,capteurpiece.id_type,id_capteur_piece,reference,id_piece from capteurpiece JOIN catalogue ON capteurpiece.id_capteur_catalogue=catalogue.id_capteur WHERE id_capteur_piece= ? AND id_capteur_catalogue = ?");
					        $Recup-> execute(array($o[0],$o[2]));

					        $Rec=$Recup->fetch();
					                   

					       
					        $inserthistorique = $bdd->prepare("INSERT INTO donnees(valeur, ladate, heure, id_piece, id_type,id_capteur_piece, numero) VALUES( ?, ?,?, ?, ?, ?,?)");
					        $inserthistorique-> execute(array($Rec['valeur'],$date ,$heure ,$Rec['id_piece'] ,$Rec['id_type'], $Rec['id_capteur_piece'], $Rec['reference'] ));
					      
					    
					  
					      }
					  }
					  if (!empty($_POST['luminosite'])) {
					     foreach ($_POST['luminosite'] as $select)
					      {
					        $o =explode(',',$select);  
					        

					        $date= date("Y-m-d");
					        $heure = date("H:i:s");

					        $insertcapteur = $bdd->prepare("UPDATE capteurpiece SET valeur=? WHERE id_capteur_piece = ? ");
					        $insertcapteur-> execute(array($o[1],$o[0]));

					        $Recup = $bdd->prepare("SELECT valeur,capteurpiece.id_type,id_capteur_piece,reference,id_piece from capteurpiece JOIN catalogue ON capteurpiece.id_capteur_catalogue=catalogue.id_capteur WHERE id_capteur_piece= ? AND id_capteur_catalogue = ?");
					        $Recup-> execute(array($o[0],$o[2]));

					        $Rec=$Recup->fetch();
					                   
					        $inserthistorique = $bdd->prepare("INSERT INTO donnees(valeur, ladate, heure, id_piece, id_type,id_capteur_piece, numero) VALUES( ?, ?,?, ?, ?, ?,?)");
					        $inserthistorique-> execute(array($Rec['valeur'],$date ,$heure ,$Rec['id_piece'] ,$Rec['id_type'], $Rec['id_capteur_piece'] ,$Rec['reference'] ));
					      
					  
					      }
					  }
					  if (isset($_POST['volet'])) {
					        $select=$_POST['volet'];
					        $o =explode(',',$select);  
					        
					        $insertcapteur = $bdd->prepare("UPDATE capteurpiece SET valeur=? WHERE id_capteur_piece = ? ");
					        $insertcapteur-> execute(array($o[1],$o[0]));

					       $Recup = $bdd->prepare("SELECT valeur,capteurpiece.id_type,id_capteur_piece,reference,id_piece from capteurpiece JOIN catalogue ON capteurpiece.id_capteur_catalogue=catalogue.id_capteur WHERE id_capteur_piece= ? AND id_capteur_catalogue = ?");
					        $Recup-> execute(array($o[0],$o[2]));

					        $Rec=$Recup->fetch();
					         
					       
					        $inserthistorique = $bdd->prepare("INSERT INTO donnees(valeur, ladate, heure, id_piece, id_type,id_capteur_piece, numero) VALUES( ?, ?,?, ?, ?, ?,?)");
					        $inserthistorique-> execute(array($Rec['valeur'],$date ,$heure ,$Rec['id_piece'] ,$Rec['id_type'], $Rec['id_capteur_piece'], $Rec['reference'] ));
					      }
					      $i=1;
      					$essai = 3;
					  while ($i<1000) {
					  	echo $_POST[1];	
					      if (isset($_POST[$i])) {
					 		
					        $select=intval($_POST[$i]);
					        $id_capteur=$_POST[$i+10];

					        $o =explode(',',$id_capteur); 
					        $insertcapteur = $bdd->prepare("UPDATE capteurpiece SET valeur=? WHERE id_capteur_piece = ? ");
					        $insertcapteur-> execute(array($select,$idcapt));

					        


					        
					      }
					    
					      else { break;
					      }
					        $i=$i+1;
					  }

					 if (!empty($_POST['humidite'])) {
					     foreach ($_POST['humidite'] as $select)
					      {
					        $o =explode(',',$select);  
					        
					        $insertcapteur = $bdd->prepare("UPDATE capteurpiece SET valeur=? WHERE id_capteur_piece = ? ");
					        $insertcapteur-> execute(array($o[1],$o[0]));


					        $date= date("Y-m-d");
					        $heure = date("H:i:s");
					        $Recup = $bdd->prepare("SELECT valeur,capteurpiece.id_type,id_capteur_piece,reference,id_piece from capteurpiece JOIN catalogue ON capteurpiece.id_capteur_catalogue=catalogue.id_capteur WHERE id_capteur_piece= ? AND id_capteur_catalogue = ?");
					        $Recup-> execute(array($o[0],$o[2]));

					        $Rec=$Recup->fetch();
					                   

					        $inserthistorique = $bdd->prepare("INSERT INTO donnees(valeur, ladate, heure, id_piece, id_type,id_capteur_piece, numero) VALUES( ?, ?,?, ?, ?, ?,?)");
					        $inserthistorique-> execute(array($Rec['valeur'],$date ,$heure ,$Rec['id_piece'] ,$Rec['id_type'], $Rec['id_capteur_piece'], $Rec['reference'] ));
					      
					  
					      }
					  }
					        		##$insertcapteur = $bdd->prepare("INSERT INTO programmation (heure,ladate,id_habitation,id_type,id_capteur) VALUES()");
					        		#$insertcapteur-> execute(array(,,));
     			}
}
?>
<html>

<body>
<form method="POST">
	<label>Date:</label>

	<input type="date" name="inserdate" placeholder="Y-m-d">
	</br></br>
	<label>Heure:</label>

	<input type="time" name="inserheure" placeholder="H:i:s">
	</br></br>
	<input type="submit" name="activer">
</form>
</body>
</html>