<?php
$contact = 'Contact';
$coordonnees = ' Contact Details';
$side_text = 'To contact us, please fill in the following form. Our team is committed to responding to you as soon as possible.';
$ask = 'Your Application';
$chat ='Access ChatBox';
$name = 'Lastname';
$surname = 'Surname';
$mail = 'Email';
$button = 'Send';
?>