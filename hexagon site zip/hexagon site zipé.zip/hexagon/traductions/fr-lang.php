<?php

$contact = 'Contact';
$coordonnees = ' Nos coordonnées';
$side_text = 'Pour nous contacter, merci de bien vouloir remplir le formulaire suivant. Notre équipe s\'engage à vous répondre dans les plus brefs délais.';
$ask = 'Votre demande';
$chat = 'Accéder à mon chat';
$name = 'Nom';
$surname = 'Prénom';
$mail = 'Email';
$button ='Envoyer';
?>