<link rel="stylesheet"  href="header_deco.css">	
	<meta charset="utf-8">
		<header>
				<img src="image/logo hexagon.png" alt="logo Hexagon" id="logo_hexagon">
				
				<div class="deco">
					<a href="deconnexion.php" class="deconnexion">Déconnexion</a>
				</div>
				<nav>
					<ul class="snip1241">
						<li><a href="maisonsallecapteur.php">Ma maison</a></li>
						<li><a href="catalogue.php">Catalogue</a></li>
						<li><a href="apropos.php">A Propos</a></li>
						<li><a href="faq.php">Aide</a></li>
		
					</ul>
				</nav>
			</header>
