<?php
session_start();
$bdd = new PDO('mysql:host=127.0.0.1;dbname=hexagon','root','',array (PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''));

if (isset($_SESSION['id'])) {
  $getidadmin = intval($_SESSION['id']);
  $reqadmin = $bdd -> prepare('SELECT admin FROM personne WHERE id = ?');
  $reqadmin -> execute(array($getidadmin));
  $user = $reqadmin -> fetch();
  if ($user['admin']!=1) {
    exit();
  }
  
}
else {
  exit();
}
?>