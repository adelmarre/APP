<link rel="stylesheet"  href="header_connexion.css">	
		<header>
				<img src="image/logo hexagon.png" alt="logo Hexagon" id="logo_hexagon">
				<meta charset="utf-8">
				<div class="co">
					<a href="index.php" class="connexion">Connexion</a>
				</div>
				<nav>
					<ul class="snip1241">
						<li><a href="index.php">Ma maison</a></li>
						<li><a href="catalogue.php">Catalogue</a></li>
						<li><a href="apropos.php">A Propos</a></li>
						<li><a href="faq.php">Aide</a></li>
				
					</ul>
				</nav>
				
			</header>

