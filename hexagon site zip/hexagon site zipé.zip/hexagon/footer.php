<link rel="stylesheet"  href="footer.css">	
		<footer>
				<a href="pagecontact.php?langue=fr">Nous Contacter</a>
				<div class='domisep'>
					Copyright &copy; Domisep2018.
				</div>
				

		</footer>